import fs from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = path.join(root, 'output');
const chart = path.join(output, 'chart', 'search-gateway');
const renderedTarget = path.join(output, 'rendered');
const reportsTarget = path.join(output, 'reports');
const helm = process.env.HELM_BIN || 'helm';

function parseCsv(text) {
  const lines = text.trim().split(/\r?\n/);
  const headers = lines.shift().split(',');
  return lines.map(line => Object.fromEntries(line.split(',').map((value, index) => [headers[index], value])));
}
function csvCell(value) {
  const text = String(value ?? '');
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}
function csvText(headers, rows) {
  return `${headers.map(csvCell).join(',')}\n${rows.map(row => headers.map(header => csvCell(row[header])).join(',')).join('\n')}\n`;
}
function runHelm(args) {
  const result = spawnSync(helm, args, { cwd: root, encoding: 'utf8', windowsHide: true });
  return {
    exitCode: result.status ?? 127,
    stdout: (result.stdout || '').replaceAll('\r\n', '\n'),
    stderr: (result.stderr || '').replaceAll('\r\n', '\n'),
    error: result.error ? String(result.error.message || result.error) : '',
  };
}
function parseDocuments(text) {
  const documents = [];
  for (const block of text.split(/^---\s*$/m)) {
    const body = block.split('\n').filter(line => !line.startsWith('# Source:')).join('\n').trim();
    if (body) documents.push(JSON.parse(body));
  }
  return documents;
}
function only(objects, kind) {
  const found = objects.filter(object => object.kind === kind);
  if (found.length !== 1) throw new Error(`expected one ${kind}, found ${found.length}`);
  return found[0];
}
function getPath(object, fieldPath) {
  if (fieldPath === 'image.tag') return object.spec.template.spec.containers[0].image.split(':').at(-1);
  if (fieldPath.startsWith('annotations.')) return object.metadata.annotations[fieldPath.slice('annotations.'.length)];
  return fieldPath.split('.').reduce((value, key) => value?.[key], object);
}
function objectKey(object) { return `${object.kind}/${object.metadata.name}`; }
async function cleanGenerated() {
  await fs.rm(renderedTarget, { recursive: true, force: true });
  await fs.rm(reportsTarget, { recursive: true, force: true });
}

async function main() {
  await cleanGenerated();
  const required = [
    'README.md',
    'chart/search-gateway/Chart.yaml',
    'chart/search-gateway/values.yaml',
    'chart/search-gateway/values.schema.json',
    'values/env/staging.yaml',
    'values/env/prod.yaml',
    'values/env/prod-rollback.yaml',
    'data/tenant_limits.csv',
    'rules/render_contract.yaml',
  ];
  const missing = [];
  for (const relative of required) {
    try { await fs.access(path.join(root, relative)); } catch { missing.push(relative); }
  }
  if (missing.length) throw Object.assign(new Error(`missing inputs:${missing.join(',')}`), { exitCode: 2 });
  try { await fs.access(path.join(chart, 'Chart.yaml')); }
  catch { throw Object.assign(new Error('missing completed chart:output/chart/search-gateway'), { exitCode: 2 }); }

  const contract = JSON.parse(await fs.readFile(path.join(root, 'rules', 'render_contract.yaml'), 'utf8'));
  const tenants = parseCsv(await fs.readFile(path.join(root, contract.tenant_source), 'utf8'));
  if (new Set(tenants.map(row => row.tenant_id)).size !== tenants.length) throw new Error('duplicate tenant_id');
  if (new Set(contract.render_cases.map(row => row.environment)).size !== contract.render_cases.length) throw new Error('duplicate environment');

  const versionRun = runHelm(['version', '--short']);
  const helmVersion = versionRun.stdout.trim();
  if (versionRun.exitCode !== 0 || helmVersion !== contract.helm_version) throw new Error(`Helm version mismatch:${helmVersion || versionRun.stderr || versionRun.error}`);
  const lint = runHelm(['lint', 'output/chart/search-gateway', '--strict']);
  if (lint.exitCode !== 0) throw new Error(`helm lint failed:${lint.stderr || lint.stdout}`);

  const stage = await fs.mkdtemp(path.join(output, '.gateway-stage-'));
  const stageRendered = path.join(stage, 'rendered');
  const stageReports = path.join(stage, 'reports');
  await fs.mkdir(stageRendered, { recursive: true });
  await fs.mkdir(stageReports, { recursive: true });
  try {
    const auditByEnvironment = {};
    for (const current of contract.render_cases) {
      const rendered = runHelm([
        'template', contract.release_name, 'output/chart/search-gateway',
        '--namespace', current.namespace,
        '-f', current.values_file,
      ]);
      if (rendered.exitCode !== 0) throw new Error(`${current.environment} render failed:${rendered.stderr}`);
      const documents = parseDocuments(rendered.stdout);
      const kinds = documents.map(object => object.kind).sort();
      if (JSON.stringify(kinds) !== JSON.stringify(contract.required_kinds.slice().sort())) throw new Error(`${current.environment} object set mismatch:${kinds.join(',')}`);
      const deployment = only(documents, 'Deployment');
      const service = only(documents, 'Service');
      const ingress = only(documents, 'Ingress');
      const hpa = only(documents, 'HorizontalPodAutoscaler');
      const labelsComplete = documents.every(object => contract.required_labels.every(label => Object.hasOwn(object.metadata.labels || {}, label)));
      const rules = ingress.spec.rules.map(rule => ({
        host: rule.host,
        path: rule.http.paths[0].path,
        service_name: rule.http.paths[0].backend.service.name,
        service_port: rule.http.paths[0].backend.service.port.number,
      }));
      auditByEnvironment[current.environment] = {
        environment: current.environment,
        namespace: current.namespace,
        values: JSON.parse(await fs.readFile(path.join(root, current.values_file), 'utf8')),
        documents,
        inventory: documents.map(object => ({ key: objectKey(object), api_version: object.apiVersion, namespace: object.metadata.namespace })).sort((left, right) => left.key.localeCompare(right.key)),
        deployment,
        service,
        ingress,
        hpa,
        rules,
        labelsComplete,
      };
      await fs.writeFile(path.join(stageRendered, `${current.environment}.yaml`), rendered.stdout, 'utf8');
    }

    const matrixRows = [];
    for (const environment of contract.matrix_environments) {
      const audit = auditByEnvironment[environment];
      for (const tenant of tenants) {
        const envValue = audit.values.tenants.find(row => row.tenantId === tenant.tenant_id);
        const rendered = Boolean(envValue?.enabled);
        const allowed = tenant.environments.split('|').includes(environment);
        if (rendered !== allowed) throw new Error(`${environment}/${tenant.tenant_id} enabled mismatch`);
        if (rendered) {
          if (envValue.host !== tenant.host || envValue.path !== tenant.path || Number(envValue.sustainedRps) !== Number(tenant.sustained_rps) || Number(envValue.burstRps) !== Number(tenant.burst_rps)) throw new Error(`${environment}/${tenant.tenant_id} values disagree with tenant source`);
          if (audit.ingress.metadata.annotations[`search.example.com/tenant-${tenant.tenant_id}-rps`] !== tenant.sustained_rps) throw new Error(`${environment}/${tenant.tenant_id} rps annotation mismatch`);
          if (audit.ingress.metadata.annotations[`search.example.com/tenant-${tenant.tenant_id}-burst`] !== tenant.burst_rps) throw new Error(`${environment}/${tenant.tenant_id} burst annotation mismatch`);
          const rule = audit.rules.find(item => item.host === tenant.host);
          if (!rule || rule.path !== tenant.path || rule.service_name !== audit.service.metadata.name || rule.service_port !== audit.service.spec.ports[0].port) throw new Error(`${environment}/${tenant.tenant_id} ingress route mismatch`);
        }
        matrixRows.push({
          environment,
          tenant_id: tenant.tenant_id,
          host: tenant.host,
          path: tenant.path,
          limit_rps: rendered ? Number(tenant.sustained_rps) : 0,
          burst_rps: rendered ? Number(tenant.burst_rps) : 0,
          rendered: rendered ? 'yes' : 'no',
          annotation_key: rendered ? `search.example.com/tenant-${tenant.tenant_id}-rps` : 'excluded_from_prod',
        });
      }
    }

    const prod = auditByEnvironment.prod;
    const rollback = auditByEnvironment['prod-rollback'];
    const objectByKind = (audit, kind) => only(audit.documents, kind);
    const deltaRows = contract.rollback_fields.map(rule => {
      const currentObject = objectByKind(prod, rule.resource);
      const rollbackObject = objectByKind(rollback, rule.resource);
      return {
        resource: objectKey(currentObject),
        field_path: rule.field_path,
        current_value: getPath(currentObject, rule.field_path),
        rollback_value: getPath(rollbackObject, rule.field_path),
        delta_type: rule.delta_type,
      };
    });

    const inventories = Object.values(auditByEnvironment).flatMap(row => row.inventory.map(item => `${row.environment}:${item.key}`));
    if (inventories.length !== new Set(inventories).size) throw new Error('duplicate rendered object identity');
    if (!Object.values(auditByEnvironment).every(row => row.labelsComplete)) throw new Error('required labels are incomplete');
    if (!Object.values(auditByEnvironment).every(row => row.rules.every(rule => rule.service_name === row.service.metadata.name && rule.service_port === row.service.spec.ports[0].port))) throw new Error('Ingress route does not match Service');
    if (!Object.values(auditByEnvironment).every(row => row.hpa.spec.scaleTargetRef.name === row.deployment.metadata.name)) throw new Error('HPA target does not match Deployment');
    await fs.writeFile(path.join(stageReports, 'tenant_limit_matrix.csv'), csvText(['environment','tenant_id','host','path','limit_rps','burst_rps','rendered','annotation_key'], matrixRows), 'utf8');
    await fs.writeFile(path.join(stageReports, 'rollback_delta.csv'), csvText(['resource','field_path','current_value','rollback_value','delta_type'], deltaRows), 'utf8');
    await fs.writeFile(path.join(stageReports, 'helm_lint_report.txt'), lint.stdout.trimEnd() + '\n', 'utf8');
    await fs.rename(stageRendered, renderedTarget);
    await fs.rename(stageReports, reportsTarget);
    await fs.rm(stage, { recursive: true, force: true });
    console.log(`rendered ${contract.render_cases.length} environments`);
  } catch (error) {
    await fs.rm(stage, { recursive: true, force: true });
    throw error;
  }
}

try {
  await main();
} catch (error) {
  await cleanGenerated();
  console.error(error.message || String(error));
  process.exit(Number.isInteger(error.exitCode) ? error.exitCode : 1);
}
