# 搜索网关Chart材料说明

chart/search-gateway是待完善的Chart，Ingress模板尚未完成，Service也需要补齐。values/env保存环境配置，data/tenant_limits.csv记录租户基线，rules/render_contract.yaml声明环境、公共资源、标签、回滚字段和交付路径。

请把完成版Chart保存到output/chart/search-gateway。在Windows PowerShell、macOS或Linux终端设置HELM_BIN指向Helm3.17.3；未设置时使用PATH中的helm。进入input_data运行node tools/run_task.mjs。入口会调用Helm执行严格lint和环境渲染，再从本次对象整理租户矩阵与回滚差异。

处理过程保持离线，不连接Kubernetes API、镜像仓库或真实搜索流量。环境配置与render_contract.yaml采用JSON兼容的YAML写法，便于入口读取合同后交给Helm处理。
